import Hero from './components/Hero';
import ChatInterface from './components/ChatInterface';
import FeatureSection from './components/FeatureSection';
import DataSources from './components/DataSources';

function App() {
  return (
    <div className="min-h-screen bg-white">
      <Hero />
      <ChatInterface />
      <FeatureSection />
      <DataSources />
    </div>
  );
}

export default App;
