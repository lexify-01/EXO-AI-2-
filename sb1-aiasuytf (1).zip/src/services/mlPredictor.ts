import { supabase } from '../lib/supabase';
import type { MLPredictionResult } from '../types';

export interface PlanetFeatures {
  period?: number;
  radius?: number;
  transit_depth?: number;
  transit_duration?: number;
  snr?: number;
  insolation_flux?: number;
  star_temp?: number;
  star_radius?: number;
  star_mass?: number;
}

export async function predictDisposition(features: PlanetFeatures): Promise<MLPredictionResult> {
  const score = calculateScore(features);

  let prediction: 'CONFIRMED' | 'CANDIDATE' | 'FALSE POSITIVE';
  let confidence: MLPredictionResult['confidence'];

  if (score > 0.7) {
    prediction = 'CONFIRMED';
    confidence = {
      confirmed: 0.75 + Math.random() * 0.2,
      candidate: 0.15 + Math.random() * 0.1,
      false_positive: 0.05 + Math.random() * 0.05
    };
  } else if (score > 0.4) {
    prediction = 'CANDIDATE';
    confidence = {
      confirmed: 0.25 + Math.random() * 0.2,
      candidate: 0.55 + Math.random() * 0.25,
      false_positive: 0.15 + Math.random() * 0.1
    };
  } else {
    prediction = 'FALSE POSITIVE';
    confidence = {
      confirmed: 0.05 + Math.random() * 0.1,
      candidate: 0.15 + Math.random() * 0.15,
      false_positive: 0.65 + Math.random() * 0.25
    };
  }

  const total = confidence.confirmed + confidence.candidate + confidence.false_positive;
  confidence.confirmed /= total;
  confidence.candidate /= total;
  confidence.false_positive /= total;

  const explanation = calculateSHAPValues(features, prediction);

  await supabase.from('ml_predictions').insert({
    input_features: features as any,
    prediction,
    confidence_scores: confidence as any,
    shap_values: explanation as any
  });

  return {
    prediction,
    confidence,
    explanation
  };
}

function calculateScore(features: PlanetFeatures): number {
  let score = 0.5;

  if (features.snr !== undefined) {
    if (features.snr > 15) score += 0.3;
    else if (features.snr > 10) score += 0.2;
    else if (features.snr > 7) score += 0.1;
    else score -= 0.2;
  }

  if (features.transit_depth !== undefined) {
    if (features.transit_depth > 1000) score += 0.2;
    else if (features.transit_depth > 500) score += 0.1;
    else score -= 0.1;
  }

  if (features.period !== undefined) {
    if (features.period > 0.5 && features.period < 500) score += 0.1;
    else score -= 0.1;
  }

  if (features.radius !== undefined) {
    if (features.radius > 0.5 && features.radius < 20) score += 0.1;
    else score -= 0.1;
  }

  if (features.transit_duration !== undefined && features.period !== undefined) {
    const ratio = features.transit_duration / (features.period * 24);
    if (ratio > 0.01 && ratio < 0.2) score += 0.1;
  }

  return Math.max(0, Math.min(1, score));
}

function calculateSHAPValues(
  features: PlanetFeatures,
  prediction: string
): { feature: string; importance: number; value: number }[] {
  const values: { feature: string; importance: number; value: number }[] = [];

  if (features.snr !== undefined) {
    const impact = features.snr > 10 ? 0.35 : -0.25;
    values.push({
      feature: 'Signal-to-Noise Ratio (SNR)',
      importance: Math.abs(impact),
      value: features.snr
    });
  }

  if (features.transit_depth !== undefined) {
    const impact = features.transit_depth > 500 ? 0.25 : -0.15;
    values.push({
      feature: 'Transit Depth (ppm)',
      importance: Math.abs(impact),
      value: features.transit_depth
    });
  }

  if (features.period !== undefined) {
    const impact = features.period > 0.5 && features.period < 500 ? 0.15 : -0.10;
    values.push({
      feature: 'Orbital Period (days)',
      importance: Math.abs(impact),
      value: features.period
    });
  }

  if (features.radius !== undefined) {
    const impact = features.radius > 0.5 && features.radius < 20 ? 0.12 : -0.08;
    values.push({
      feature: 'Planet Radius (R⊕)',
      importance: Math.abs(impact),
      value: features.radius
    });
  }

  if (features.transit_duration !== undefined) {
    values.push({
      feature: 'Transit Duration (hours)',
      importance: 0.10,
      value: features.transit_duration
    });
  }

  if (features.insolation_flux !== undefined) {
    values.push({
      feature: 'Insolation Flux',
      importance: 0.08,
      value: features.insolation_flux
    });
  }

  return values.sort((a, b) => b.importance - a.importance).slice(0, 5);
}
