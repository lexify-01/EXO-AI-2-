import type { ExoplanetData } from '../types';
import type { QueryTool } from './queryRouter';

export function generateConversationalResponse(
  query: string,
  tool: QueryTool,
  data?: ExoplanetData[],
  baseExplanation?: string
): string {
  const lowerQuery = query.toLowerCase();

  if (tool === 'info') {
    return baseExplanation || "I'd be happy to explain that term!";
  }

  if (tool === 'ml') {
    return "I'll analyze those features using our machine learning classifier trained on NASA data. The prediction will include confidence scores and SHAP values showing which features most influenced the classification.";
  }

  if (tool === 'visualization') {
    return "Let me generate that visualization for you. I'll create charts that help you understand the patterns in the exoplanet data.";
  }

  if (tool === 'comparison') {
    return "I'll compare those two targets side-by-side, showing you the differences in their physical characteristics, orbital parameters, and observational properties.";
  }

  if (!data || data.length === 0) {
    return `I searched the database but didn't find any exoplanets matching those criteria. Try:\n\n- Adjusting the parameter ranges\n- Removing some filters\n- Asking about a specific mission (Kepler, TESS, or K2)\n\nOr ask me to explain any terms you're curious about!`;
  }

  const responseBuilder: string[] = [];

  responseBuilder.push(`Great question! I found **${data.length} exoplanets** matching your search.`);

  const missions = new Set(data.map(d => d.mission));
  const dispositions = data.reduce((acc, d) => {
    acc[d.disposition] = (acc[d.disposition] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  if (missions.size > 1) {
    responseBuilder.push(`\nThese include discoveries from ${Array.from(missions).join(', ')} missions.`);
  }

  const confirmed = dispositions['CONFIRMED'] || 0;
  const candidates = Object.entries(dispositions)
    .filter(([key]) => key.includes('CANDIDATE') || key === 'PC')
    .reduce((sum, [_, count]) => sum + count, 0);

  if (confirmed > 0) {
    responseBuilder.push(`\n${confirmed} are confirmed planets${candidates > 0 ? ` and ${candidates} are candidates awaiting confirmation` : ''}.`);
  } else if (candidates > 0) {
    responseBuilder.push(`\n${candidates} are candidates awaiting confirmation.`);
  }

  const withRadius = data.filter(d => d.radius).length;
  if (withRadius > 0 && (lowerQuery.includes('radius') || lowerQuery.includes('size'))) {
    const avgRadius = data.reduce((sum, d) => sum + (d.radius || 0), 0) / withRadius;
    responseBuilder.push(`\nThe average radius is ${avgRadius.toFixed(2)} Earth radii.`);
  }

  const withPeriod = data.filter(d => d.period).length;
  if (withPeriod > 0 && lowerQuery.includes('period')) {
    const avgPeriod = data.reduce((sum, d) => sum + (d.period || 0), 0) / withPeriod;
    responseBuilder.push(`\nAverage orbital period is ${avgPeriod.toFixed(2)} days.`);
  }

  const withDistance = data.filter(d => d.distance).length;
  if (withDistance > 0 && (lowerQuery.includes('distance') || lowerQuery.includes('pc') || lowerQuery.includes('parsec'))) {
    const avgDistance = data.reduce((sum, d) => sum + (d.distance || 0), 0) / withDistance;
    responseBuilder.push(`\nAverage distance from Earth is ${avgDistance.toFixed(1)} parsecs.`);
  }

  if (data.length <= 5) {
    responseBuilder.push('\n\nHere are the details:');
  } else {
    responseBuilder.push('\n\nResults are shown in the table below. You can sort and explore the data.');
  }

  responseBuilder.push('\n\nWant to know more? Ask me to:');
  responseBuilder.push('- Compare two specific targets');
  responseBuilder.push('- Explain any technical terms');
  responseBuilder.push('- Show visualizations');
  responseBuilder.push('- Predict classification for custom parameters');

  return responseBuilder.join('');
}

export function generateFollowUpSuggestions(data: ExoplanetData[]): string[] {
  const suggestions: string[] = [];

  if (data.length > 0) {
    const firstPlanet = data[0];
    suggestions.push(`Tell me more about ${firstPlanet.name}`);

    if (data.length > 1) {
      suggestions.push(`Compare ${data[0].name} and ${data[1].name}`);
    }

    const hasRadius = data.some(d => d.radius);
    if (hasRadius) {
      suggestions.push('Show me a period-radius plot of these results');
    }
  }

  suggestions.push('What makes a good exoplanet candidate?');
  suggestions.push('How are false positives identified?');

  return suggestions.slice(0, 4);
}
