import { supabase } from '../lib/supabase';
import type { ExoplanetData, QueryFilter } from '../types';

export type QueryTool = 'sql' | 'ml' | 'visualization' | 'comparison' | 'info';

export interface RouterResult {
  tool: QueryTool;
  data?: ExoplanetData[];
  visualization?: string;
  explanation: string;
  citations: string[];
  query?: string;
}

const GLOSSARY: Record<string, string> = {
  'period': 'Orbital period: Time it takes the planet to complete one orbit around its star',
  'radius': 'Planet radius: Size of the planet measured in Earth radii (R⊕)',
  'snr': 'Signal-to-noise ratio: Measure of detection confidence',
  'disposition': 'Classification status: CONFIRMED (verified planet), CANDIDATE (potential planet), FALSE POSITIVE (not a planet)',
  'transit depth': 'Amount of starlight blocked when planet passes in front of star',
  'insolation flux': 'Amount of stellar energy received by the planet relative to Earth',
  'equilibrium temperature': 'Theoretical surface temperature based on stellar radiation',
  'teff': 'Effective temperature of the host star'
};

export async function routeQuery(query: string): Promise<RouterResult> {
  const lowercaseQuery = query.toLowerCase();

  if (lowercaseQuery.includes('compare') || lowercaseQuery.includes('vs')) {
    return {
      tool: 'comparison',
      explanation: 'Initiating comparison mode',
      citations: []
    };
  }

  if (lowercaseQuery.includes('predict') || lowercaseQuery.includes('classify') || lowercaseQuery.includes('ml')) {
    return {
      tool: 'ml',
      explanation: 'Using machine learning classifier for prediction',
      citations: ['LightGBM classifier trained on NASA Exoplanet Archive data']
    };
  }

  if (lowercaseQuery.includes('plot') || lowercaseQuery.includes('chart') || lowercaseQuery.includes('visualize') || lowercaseQuery.includes('distribution')) {
    return {
      tool: 'visualization',
      explanation: 'Generating visualization',
      citations: []
    };
  }

  if (lowercaseQuery.includes('what is') || lowercaseQuery.includes('explain') || lowercaseQuery.includes('define')) {
    const explanation = Object.entries(GLOSSARY)
      .filter(([term]) => lowercaseQuery.includes(term))
      .map(([_, def]) => def)
      .join('. ');

    return {
      tool: 'info',
      explanation: explanation || 'Please specify which term you would like explained.',
      citations: ['NASA Exoplanet Archive glossary']
    };
  }

  const filters = parseQueryFilters(query);
  const data = await executeQuery(filters);

  return {
    tool: 'sql',
    data,
    explanation: `Found ${data.length} results matching your criteria`,
    citations: ['NASA Exoplanet Archive (Kepler/K2/TESS tables)'],
    query: JSON.stringify(filters, null, 2)
  };
}

function parseQueryFilters(query: string): QueryFilter {
  const filters: QueryFilter = {};
  const lowercaseQuery = query.toLowerCase();

  if (lowercaseQuery.includes('kepler')) filters.mission = ['Kepler'];
  if (lowercaseQuery.includes('tess')) filters.mission = ['TESS'];
  if (lowercaseQuery.includes('k2')) filters.mission = ['K2'];

  if (lowercaseQuery.includes('confirmed')) {
    filters.disposition = ['CONFIRMED'];
  } else if (lowercaseQuery.includes('candidate')) {
    filters.disposition = ['CANDIDATE', 'PC'];
  } else if (lowercaseQuery.includes('false positive')) {
    filters.disposition = ['FALSE POSITIVE', 'FP'];
  }

  const periodMatch = query.match(/period[:\s]+(\d+(?:\.\d+)?)\s*-\s*(\d+(?:\.\d+)?)/i);
  if (periodMatch) {
    filters.period = [parseFloat(periodMatch[1]), parseFloat(periodMatch[2])];
  }

  const radiusMatch = query.match(/(?:radius|rp?)[:\s<>]+(\d+(?:\.\d+)?)/i);
  if (radiusMatch) {
    filters.radius = [0, parseFloat(radiusMatch[1])];
  }

  const tempMatch = query.match(/(?:temp|teff)[:\s]+(\d+)\s*-\s*(\d+)/i);
  if (tempMatch) {
    filters.star_temp = [parseFloat(tempMatch[1]), parseFloat(tempMatch[2])];
  }

  const distMatch = query.match(/(?:within|distance[:\s<]+)(\d+(?:\.\d+)?)\s*pc/i);
  if (distMatch) {
    filters.distance = [0, parseFloat(distMatch[1])];
  }

  const snrMatch = query.match(/snr[:\s>]+(\d+(?:\.\d+)?)/i);
  if (snrMatch) {
    filters.snr_min = parseFloat(snrMatch[1]);
  }

  return filters;
}

async function executeQuery(filters: QueryFilter): Promise<ExoplanetData[]> {
  const results: ExoplanetData[] = [];

  const missions = filters.mission || ['Kepler', 'TESS', 'K2'];

  if (missions.includes('Kepler')) {
    let query = supabase.from('kepler_objects').select('*');

    if (filters.disposition) {
      query = query.in('disposition', filters.disposition);
    }
    if (filters.period) {
      query = query.gte('period', filters.period[0]).lte('period', filters.period[1]);
    }
    if (filters.radius) {
      query = query.gte('radius', filters.radius[0]).lte('radius', filters.radius[1]);
    }
    if (filters.star_temp) {
      query = query.gte('star_temp', filters.star_temp[0]).lte('star_temp', filters.star_temp[1]);
    }
    if (filters.distance) {
      query = query.gte('distance', filters.distance[0]).lte('distance', filters.distance[1]);
    }
    if (filters.snr_min) {
      query = query.gte('snr', filters.snr_min);
    }

    const { data, error } = await query.limit(100);

    if (!error && data) {
      results.push(...data.map(obj => ({
        id: obj.id,
        name: obj.kepler_name || obj.koi_name,
        mission: 'Kepler' as const,
        disposition: obj.disposition,
        period: obj.period || undefined,
        radius: obj.radius || undefined,
        equilibrium_temp: obj.equilibrium_temp || undefined,
        insolation_flux: obj.insolation_flux || undefined,
        transit_depth: obj.transit_depth || undefined,
        transit_duration: obj.transit_duration || undefined,
        snr: obj.snr || undefined,
        star_temp: obj.star_temp || undefined,
        star_radius: obj.star_radius || undefined,
        star_mass: obj.star_mass || undefined,
        distance: obj.distance || undefined,
        source: obj.data_source || undefined,
        last_updated: obj.last_updated
      })));
    }
  }

  if (missions.includes('TESS')) {
    let query = supabase.from('tess_objects').select('*');

    if (filters.disposition) {
      query = query.in('tfopwg_disposition', filters.disposition);
    }
    if (filters.period) {
      query = query.gte('period', filters.period[0]).lte('period', filters.period[1]);
    }
    if (filters.radius) {
      query = query.gte('radius', filters.radius[0]).lte('radius', filters.radius[1]);
    }
    if (filters.star_temp) {
      query = query.gte('star_temp', filters.star_temp[0]).lte('star_temp', filters.star_temp[1]);
    }
    if (filters.distance) {
      query = query.gte('distance', filters.distance[0]).lte('distance', filters.distance[1]);
    }
    if (filters.snr_min) {
      query = query.gte('snr', filters.snr_min);
    }

    const { data, error } = await query.limit(100);

    if (!error && data) {
      results.push(...data.map(obj => ({
        id: obj.id,
        name: obj.toi_name,
        mission: 'TESS' as const,
        disposition: obj.tfopwg_disposition,
        period: obj.period || undefined,
        radius: obj.radius || undefined,
        equilibrium_temp: obj.equilibrium_temp || undefined,
        insolation_flux: obj.insolation_flux || undefined,
        transit_depth: obj.transit_depth || undefined,
        transit_duration: obj.transit_duration || undefined,
        snr: obj.snr || undefined,
        star_temp: obj.star_temp || undefined,
        star_radius: obj.star_radius || undefined,
        star_mass: obj.star_mass || undefined,
        distance: obj.distance || undefined,
        source: obj.data_source || undefined,
        last_updated: obj.last_updated
      })));
    }
  }

  if (missions.includes('K2')) {
    let query = supabase.from('k2_objects').select('*');

    if (filters.disposition) {
      query = query.in('archive_disposition', filters.disposition);
    }
    if (filters.period) {
      query = query.gte('period', filters.period[0]).lte('period', filters.period[1]);
    }
    if (filters.radius) {
      query = query.gte('radius', filters.radius[0]).lte('radius', filters.radius[1]);
    }
    if (filters.star_temp) {
      query = query.gte('star_temp', filters.star_temp[0]).lte('star_temp', filters.star_temp[1]);
    }
    if (filters.distance) {
      query = query.gte('distance', filters.distance[0]).lte('distance', filters.distance[1]);
    }
    if (filters.snr_min) {
      query = query.gte('snr', filters.snr_min);
    }

    const { data, error } = await query.limit(100);

    if (!error && data) {
      results.push(...data.map(obj => ({
        id: obj.id,
        name: obj.planet_name || obj.epic_id,
        mission: 'K2' as const,
        disposition: obj.archive_disposition,
        period: obj.period || undefined,
        radius: obj.radius || undefined,
        equilibrium_temp: obj.equilibrium_temp || undefined,
        insolation_flux: obj.insolation_flux || undefined,
        transit_depth: obj.transit_depth || undefined,
        transit_duration: obj.transit_duration || undefined,
        snr: obj.snr || undefined,
        star_temp: obj.star_temp || undefined,
        star_radius: obj.star_radius || undefined,
        star_mass: obj.star_mass || undefined,
        distance: obj.distance || undefined,
        source: obj.data_source || undefined,
        last_updated: obj.last_updated
      })));
    }
  }

  return results;
}

export async function searchByName(name: string): Promise<ExoplanetData | null> {
  const normalized = name.trim().toLowerCase();

  const { data: keplerData } = await supabase
    .from('kepler_objects')
    .select('*')
    .or(`koi_name.ilike.%${normalized}%,kepler_name.ilike.%${normalized}%`)
    .limit(1)
    .maybeSingle();

  if (keplerData) {
    return {
      id: keplerData.id,
      name: keplerData.kepler_name || keplerData.koi_name,
      mission: 'Kepler',
      disposition: keplerData.disposition,
      period: keplerData.period || undefined,
      radius: keplerData.radius || undefined,
      equilibrium_temp: keplerData.equilibrium_temp || undefined,
      insolation_flux: keplerData.insolation_flux || undefined,
      star_temp: keplerData.star_temp || undefined,
      distance: keplerData.distance || undefined,
      source: keplerData.data_source || undefined,
      last_updated: keplerData.last_updated
    };
  }

  const { data: tessData } = await supabase
    .from('tess_objects')
    .select('*')
    .ilike('toi_name', `%${normalized}%`)
    .limit(1)
    .maybeSingle();

  if (tessData) {
    return {
      id: tessData.id,
      name: tessData.toi_name,
      mission: 'TESS',
      disposition: tessData.tfopwg_disposition,
      period: tessData.period || undefined,
      radius: tessData.radius || undefined,
      equilibrium_temp: tessData.equilibrium_temp || undefined,
      insolation_flux: tessData.insolation_flux || undefined,
      star_temp: tessData.star_temp || undefined,
      distance: tessData.distance || undefined,
      source: tessData.data_source || undefined,
      last_updated: tessData.last_updated
    };
  }

  const { data: k2Data } = await supabase
    .from('k2_objects')
    .select('*')
    .or(`epic_id.ilike.%${normalized}%,planet_name.ilike.%${normalized}%`)
    .limit(1)
    .maybeSingle();

  if (k2Data) {
    return {
      id: k2Data.id,
      name: k2Data.planet_name || k2Data.epic_id,
      mission: 'K2',
      disposition: k2Data.archive_disposition,
      period: k2Data.period || undefined,
      radius: k2Data.radius || undefined,
      equilibrium_temp: k2Data.equilibrium_temp || undefined,
      insolation_flux: k2Data.insolation_flux || undefined,
      star_temp: k2Data.star_temp || undefined,
      distance: k2Data.distance || undefined,
      source: k2Data.data_source || undefined,
      last_updated: k2Data.last_updated
    };
  }

  return null;
}
