export interface ExoplanetData {
  id: string;
  name: string;
  mission: 'Kepler' | 'TESS' | 'K2';
  disposition: string;
  period?: number;
  radius?: number;
  equilibrium_temp?: number;
  insolation_flux?: number;
  transit_depth?: number;
  transit_duration?: number;
  snr?: number;
  star_temp?: number;
  star_radius?: number;
  star_mass?: number;
  distance?: number;
  source?: string;
  last_updated?: string;
}

export interface ChatMessageType {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  metadata?: {
    tool?: string;
    query?: string;
    citations?: string[];
    visualizations?: string[];
    confidence?: number;
    dataCount?: number;
  };
  timestamp: Date;
}

export interface MLPredictionResult {
  prediction: 'CONFIRMED' | 'CANDIDATE' | 'FALSE POSITIVE';
  confidence: {
    confirmed: number;
    candidate: number;
    false_positive: number;
  };
  explanation: {
    feature: string;
    importance: number;
    value: number;
  }[];
}

export interface QueryFilter {
  mission?: ('Kepler' | 'TESS' | 'K2')[];
  disposition?: string[];
  period?: [number, number];
  radius?: [number, number];
  star_temp?: [number, number];
  distance?: [number, number];
  snr_min?: number;
}
