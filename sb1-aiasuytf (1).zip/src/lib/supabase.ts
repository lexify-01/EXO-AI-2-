import { createClient } from '@supabase/supabase-js';
import type { Database } from './database.types';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey);

export type KeplerObject = Database['public']['Tables']['kepler_objects']['Row'];
export type TessObject = Database['public']['Tables']['tess_objects']['Row'];
export type K2Object = Database['public']['Tables']['k2_objects']['Row'];
export type ChatSession = Database['public']['Tables']['chat_sessions']['Row'];
export type ChatMessage = Database['public']['Tables']['chat_messages']['Row'];
export type MLPrediction = Database['public']['Tables']['ml_predictions']['Row'];
