export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      kepler_objects: {
        Row: {
          id: string
          koi_name: string
          kepler_name: string | null
          disposition: string
          period: number | null
          period_err: number | null
          radius: number | null
          radius_err: number | null
          equilibrium_temp: number | null
          insolation_flux: number | null
          transit_depth: number | null
          transit_duration: number | null
          snr: number | null
          star_temp: number | null
          star_radius: number | null
          star_mass: number | null
          distance: number | null
          ra: number | null
          dec: number | null
          data_source: string | null
          last_updated: string
          created_at: string
        }
        Insert: Omit<Database['public']['Tables']['kepler_objects']['Row'], 'id' | 'created_at'>
        Update: Partial<Database['public']['Tables']['kepler_objects']['Insert']>
      }
      tess_objects: {
        Row: {
          id: string
          toi_name: string
          tic_id: string | null
          tfopwg_disposition: string
          period: number | null
          period_err: number | null
          radius: number | null
          radius_err: number | null
          equilibrium_temp: number | null
          insolation_flux: number | null
          transit_depth: number | null
          transit_duration: number | null
          snr: number | null
          star_temp: number | null
          star_radius: number | null
          star_mass: number | null
          distance: number | null
          ra: number | null
          dec: number | null
          data_source: string | null
          last_updated: string
          created_at: string
        }
        Insert: Omit<Database['public']['Tables']['tess_objects']['Row'], 'id' | 'created_at'>
        Update: Partial<Database['public']['Tables']['tess_objects']['Insert']>
      }
      k2_objects: {
        Row: {
          id: string
          epic_id: string
          planet_name: string | null
          archive_disposition: string
          period: number | null
          period_err: number | null
          radius: number | null
          radius_err: number | null
          equilibrium_temp: number | null
          insolation_flux: number | null
          transit_depth: number | null
          transit_duration: number | null
          snr: number | null
          star_temp: number | null
          star_radius: number | null
          star_mass: number | null
          distance: number | null
          ra: number | null
          dec: number | null
          data_source: string | null
          last_updated: string
          created_at: string
        }
        Insert: Omit<Database['public']['Tables']['k2_objects']['Row'], 'id' | 'created_at'>
        Update: Partial<Database['public']['Tables']['k2_objects']['Insert']>
      }
      chat_sessions: {
        Row: {
          id: string
          user_id: string | null
          created_at: string
          last_activity: string
        }
        Insert: Omit<Database['public']['Tables']['chat_sessions']['Row'], 'id' | 'created_at'>
        Update: Partial<Database['public']['Tables']['chat_sessions']['Insert']>
      }
      chat_messages: {
        Row: {
          id: string
          session_id: string
          role: 'user' | 'assistant'
          content: string
          metadata: Json | null
          created_at: string
        }
        Insert: Omit<Database['public']['Tables']['chat_messages']['Row'], 'id' | 'created_at'>
        Update: Partial<Database['public']['Tables']['chat_messages']['Insert']>
      }
      ml_predictions: {
        Row: {
          id: string
          session_id: string | null
          input_features: Json
          prediction: string
          confidence_scores: Json
          shap_values: Json | null
          created_at: string
        }
        Insert: Omit<Database['public']['Tables']['ml_predictions']['Row'], 'id' | 'created_at'>
        Update: Partial<Database['public']['Tables']['ml_predictions']['Insert']>
      }
    }
  }
}
