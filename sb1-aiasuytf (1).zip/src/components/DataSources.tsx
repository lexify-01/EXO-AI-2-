import { ExternalLink, Database, Telescope } from 'lucide-react';

const sources = [
  {
    name: 'NASA Exoplanet Archive',
    missions: ['Kepler', 'K2', 'TESS'],
    description: 'Comprehensive tables with mission dispositions and update timestamps',
    url: ''
  },
  {
    name: 'Kepler Objects of Interest',
    missions: ['Kepler'],
    description: 'All confirmed exoplanets, candidates, and false positives from Kepler mission',
    url: 'https://exoplanetarchive.ipac.caltech.edu/'
  },
  {
    name: 'TESS Objects of Interest',
    missions: ['TESS'],
    description: 'TOI catalog with TFOPWG dispositions (CONFIRMED/PC/FP/APC/KP)',
    url: 'https://exoplanetarchive.ipac.caltech.edu/docs/'
  },
  {
    name: 'K2 Planets and Candidates',
    missions: ['K2'],
    description: 'K2 mission data with archive dispositions and EPIC identifiers',
    url: 'https://exoplanetarchive.ipac.caltech.edu/docs/'
  }
];

export default function DataSources() {
  return (
    <div className="bg-white py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-slate-900 mb-4">
            Data Sources
          </h2>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto">
            Powered by NASA's official exoplanet databases
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {sources.map((source, idx) => (
            <div
              key={idx}
              className="bg-slate-50 rounded-xl p-6 border border-slate-200 hover:border-blue-400 transition-all"
            >
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0 w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                  {idx === 0 ? (
                    <Database className="w-5 h-5 text-blue-600" />
                  ) : (
                    <Telescope className="w-5 h-5 text-blue-600" />
                  )}
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <h3 className="font-semibold text-slate-900">
                      {source.name}
                    </h3>
                    <a
                      href={source.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-600 hover:text-blue-700"
                    >
                      <ExternalLink className="w-4 h-4" />
                    </a>
                  </div>
                  <div className="flex flex-wrap gap-2 mb-3">
                    {source.missions.map((mission) => (
                      <span
                        key={mission}
                        className="px-2 py-1 text-xs font-medium rounded bg-blue-100 text-blue-700"
                      >
                        {mission}
                      </span>
                    ))}
                  </div>
                  <p className="text-sm text-slate-600 leading-relaxed">
                    {source.description}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 bg-gradient-to-br from-blue-50 to-slate-50 rounded-xl p-8 border border-blue-200">
          <h3 className="text-xl font-semibold text-slate-900 mb-4 flex items-center gap-2">
            <Database className="w-6 h-6 text-blue-600" />
            Trust & Transparency
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-sm">
            <div>
              <h4 className="font-semibold text-slate-800 mb-2">Model Card</h4>
              <p className="text-slate-600">
                Data splits, metrics, class imbalance notes, and failure modes documented
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-slate-800 mb-2">Citations</h4>
              <p className="text-slate-600">
                Every table includes source references and last update timestamps
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-slate-800 mb-2">Reproducibility</h4>
              <p className="text-slate-600">
                Download results, export queries, and share permalinks
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
