import { ExternalLink } from 'lucide-react';
import type { ExoplanetData } from '../types';

interface ResultsTableProps {
  data: ExoplanetData[];
}

export default function ResultsTable({ data }: ResultsTableProps) {
  if (data.length === 0) {
    return (
      <div className="text-center py-8 text-slate-500">
        No results found
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-slate-200">
            <th className="text-left py-3 px-4 font-semibold text-slate-700">Name</th>
            <th className="text-left py-3 px-4 font-semibold text-slate-700">Mission</th>
            <th className="text-left py-3 px-4 font-semibold text-slate-700">Status</th>
            <th className="text-right py-3 px-4 font-semibold text-slate-700">Period (d)</th>
            <th className="text-right py-3 px-4 font-semibold text-slate-700">Radius (R⊕)</th>
            <th className="text-right py-3 px-4 font-semibold text-slate-700">Temp (K)</th>
            <th className="text-right py-3 px-4 font-semibold text-slate-700">Distance (pc)</th>
            <th className="text-right py-3 px-4 font-semibold text-slate-700">SNR</th>
          </tr>
        </thead>
        <tbody>
          {data.slice(0, 50).map((item) => (
            <tr key={item.id} className="border-b border-slate-100 hover:bg-slate-50">
              <td className="py-3 px-4 font-medium text-slate-800">{item.name}</td>
              <td className="py-3 px-4 text-slate-600">
                <span className={`px-2 py-1 rounded text-xs font-medium ${
                  item.mission === 'Kepler' ? 'bg-purple-100 text-purple-700' :
                  item.mission === 'TESS' ? 'bg-green-100 text-green-700' :
                  'bg-orange-100 text-orange-700'
                }`}>
                  {item.mission}
                </span>
              </td>
              <td className="py-3 px-4">
                <span className={`px-2 py-1 rounded text-xs font-medium ${
                  item.disposition === 'CONFIRMED' ? 'bg-blue-100 text-blue-700' :
                  item.disposition.includes('CANDIDATE') || item.disposition === 'PC' ? 'bg-yellow-100 text-yellow-700' :
                  'bg-red-100 text-red-700'
                }`}>
                  {item.disposition}
                </span>
              </td>
              <td className="py-3 px-4 text-right text-slate-600">
                {item.period ? item.period.toFixed(2) : '—'}
              </td>
              <td className="py-3 px-4 text-right text-slate-600">
                {item.radius ? item.radius.toFixed(2) : '—'}
              </td>
              <td className="py-3 px-4 text-right text-slate-600">
                {item.equilibrium_temp ? Math.round(item.equilibrium_temp) : '—'}
              </td>
              <td className="py-3 px-4 text-right text-slate-600">
                {item.distance ? item.distance.toFixed(1) : '—'}
              </td>
              <td className="py-3 px-4 text-right text-slate-600">
                {item.snr ? item.snr.toFixed(1) : '—'}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {data.length > 50 && (
        <div className="text-center py-4 text-sm text-slate-500">
          Showing 50 of {data.length} results
        </div>
      )}
    </div>
  );
}
