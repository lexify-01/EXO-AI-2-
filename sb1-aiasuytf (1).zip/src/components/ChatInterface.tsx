import { useState, useRef, useEffect } from 'react';
import { Send, Sparkles, Loader2, Download, RefreshCw } from 'lucide-react';
import type { ChatMessageType, ExoplanetData } from '../types';
import { routeQuery } from '../services/queryRouter';
import { generateConversationalResponse } from '../services/conversationalAI';
import ChatMessage from './ChatMessage';
import ResultsTable from './ResultsTable';
import PredictionCard from './PredictionCard';
import { predictDisposition, type PlanetFeatures } from '../services/mlPredictor';

const SAMPLE_PROMPTS = [
  "Show TESS candidates with period 5-30 d, radius < 2 R⊕",
  "List confirmed Kepler planets within 150 pc",
  "What is signal-to-noise ratio?",
  "Compare TOI-700 d vs Kepler-186 f"
];

export default function ChatInterface() {
  const [messages, setMessages] = useState<ChatMessageType[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingData, setIsLoadingData] = useState(false);
  const [lastResults, setLastResults] = useState<ExoplanetData[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage: ChatMessageType = {
      id: crypto.randomUUID(),
      role: 'user',
      content: input,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const result = await routeQuery(input);

      if (result.data) {
        setLastResults(result.data);
      }

      const conversationalResponse = generateConversationalResponse(
        input,
        result.tool,
        result.data,
        result.explanation
      );

      const assistantMessage: ChatMessageType = {
        id: crypto.randomUUID(),
        role: 'assistant',
        content: conversationalResponse,
        metadata: {
          tool: result.tool,
          query: result.query,
          citations: result.citations,
          dataCount: result.data?.length
        },
        timestamp: new Date()
      };

      setMessages(prev => [...prev, assistantMessage]);

    } catch (error) {
      const errorMessage: ChatMessageType = {
        id: crypto.randomUUID(),
        role: 'assistant',
        content: 'Sorry, I encountered an error processing your request. Please try again.',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSamplePrompt = (prompt: string) => {
    setInput(prompt);
  };

  const handleLoadData = async () => {
    setIsLoadingData(true);
    try {
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/fetch-exoplanet-data`;
      const response = await fetch(apiUrl, {
        headers: {
          'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
        },
      });

      const result = await response.json();

      if (result.success) {
        const message: ChatMessageType = {
          id: crypto.randomUUID(),
          role: 'assistant',
          content: `Data successfully loaded from NASA Exoplanet Archive:\n\n- Kepler objects: ${result.kepler_count}\n- TESS objects: ${result.tess_count}\n\nYou can now query the database!`,
          timestamp: new Date()
        };
        setMessages(prev => [...prev, message]);
      } else {
        throw new Error(result.error);
      }
    } catch (error) {
      const errorMessage: ChatMessageType = {
        id: crypto.randomUUID(),
        role: 'assistant',
        content: `Failed to load data: ${error instanceof Error ? error.message : 'Unknown error'}`,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoadingData(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-4 flex justify-end">
        <button
          onClick={handleLoadData}
          disabled={isLoadingData}
          className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:bg-slate-300 disabled:cursor-not-allowed transition-colors flex items-center gap-2 text-sm"
        >
          {isLoadingData ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              Loading Data...
            </>
          ) : (
            <>
              <Download className="w-4 h-4" />
              Load NASA Data
            </>
          )}
        </button>
      </div>
      <div className="bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden">
        <div className="h-[600px] flex flex-col">
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {messages.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center">
                <Sparkles className="w-12 h-12 text-blue-500 mb-4" />
                <h3 className="text-xl font-semibold text-slate-800 mb-2">
                  Ask me anything about exoplanets
                </h3>
                <p className="text-slate-600 mb-6 max-w-md">
                  Query NASA's exoplanet database using natural language
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 w-full max-w-2xl">
                  {SAMPLE_PROMPTS.map((prompt, idx) => (
                    <button
                      key={idx}
                      onClick={() => handleSamplePrompt(prompt)}
                      className="text-left p-4 rounded-lg border border-slate-200 hover:border-blue-400 hover:bg-blue-50 transition-all text-sm text-slate-700"
                    >
                      {prompt}
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <>
                {messages.map((message) => (
                  <div key={message.id}>
                    <ChatMessage message={message} />
                    {message.metadata?.dataCount && lastResults.length > 0 && (
                      <div className="mt-3 mb-3">
                        <ResultsTable data={lastResults} />
                      </div>
                    )}
                  </div>
                ))}
                {isLoading && (
                  <div className="flex items-center gap-2 text-slate-600">
                    <Loader2 className="w-5 h-5 animate-spin" />
                    <span>Analyzing your query...</span>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </>
            )}
          </div>

          <form onSubmit={handleSubmit} className="p-4 border-t border-slate-200 bg-slate-50">
            <div className="flex gap-3">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ask about exoplanets, predict classifications, or request visualizations..."
                className="flex-1 px-4 py-3 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                disabled={isLoading}
              />
              <button
                type="submit"
                disabled={isLoading || !input.trim()}
                className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-slate-300 disabled:cursor-not-allowed transition-colors flex items-center gap-2"
              >
                <Send className="w-5 h-5" />
              </button>
            </div>
          </form>
        </div>
      </div>

      <div className="mt-6 text-center text-sm text-slate-500">
        ExoGPT is a research tool. Results are generated from public datasets and ML models
        and should be validated against primary sources.
      </div>
    </div>
  );
}
