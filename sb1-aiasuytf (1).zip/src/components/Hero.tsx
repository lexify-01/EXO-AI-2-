import { Rocket, Database, Brain } from 'lucide-react';

export default function Hero() {
  return (
    <div className="bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center">
          <div className="flex justify-center mb-6">
            <div className="p-4 bg-blue-600/20 rounded-full backdrop-blur-sm border border-blue-400/30">
              <Rocket className="w-16 h-16 text-blue-300" />
            </div>
          </div>

          <h1 className="text-5xl font-bold mb-4 tracking-tight">
            ExoGPT
          </h1>

          <p className="text-2xl text-blue-200 mb-6 font-light">
            AI Database for Exoplanets
          </p>

          <p className="text-lg text-slate-300 max-w-3xl mx-auto mb-8 leading-relaxed">
            Ask in plain English. Get verified facts, charts, and ML-backed classifications
            from NASA's Kepler, K2, and TESS data—instantly.
          </p>

          <div className="flex flex-wrap justify-center gap-8 mt-12">
            <div className="flex items-center gap-3">
              <Database className="w-6 h-6 text-blue-400" />
              <span className="text-sm text-slate-300">NASA Exoplanet Archive</span>
            </div>
            <div className="flex items-center gap-3">
              <Brain className="w-6 h-6 text-blue-400" />
              <span className="text-sm text-slate-300">ML Classification</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
