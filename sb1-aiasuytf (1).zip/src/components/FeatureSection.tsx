import { Search, Brain, BarChart3, GitCompare, FileText, Eye } from 'lucide-react';

const features = [
  {
    icon: Search,
    title: 'Chat to Search',
    description: 'Query NASA datasets using natural language. Ask complex questions and get structured answers with citations.'
  },
  {
    icon: Brain,
    title: 'Predict & Explain',
    description: 'Upload candidate features and get CONFIRMED/CANDIDATE/FALSE POSITIVE predictions with SHAP explanations.'
  },
  {
    icon: BarChart3,
    title: 'Interactive Visuals',
    description: 'Period-radius plots, SNR distributions, and light-curve viewers with color-blind-safe palettes.'
  },
  {
    icon: GitCompare,
    title: 'Compare Targets',
    description: 'Side-by-side analysis of two targets with feature deltas and model rationale.'
  },
  {
    icon: FileText,
    title: 'Grounded Facts',
    description: 'Every answer cites tables or papers with update timestamps and source references.'
  },
  {
    icon: Eye,
    title: 'Full Transparency',
    description: 'View SQL queries, filters, and uncertainty bands. Download results and share permalinks.'
  }
];

export default function FeatureSection() {
  return (
    <div className="bg-slate-50 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-slate-900 mb-4">
            What You Can Do
          </h2>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto">
            A conversational, research-grade portal to the exoplanet universe
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, idx) => {
            const Icon = feature.icon;
            return (
              <div
                key={idx}
                className="bg-white rounded-xl p-6 border border-slate-200 hover:border-blue-400 hover:shadow-lg transition-all"
              >
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                  <Icon className="w-6 h-6 text-blue-600" />
                </div>
                <h3 className="text-lg font-semibold text-slate-900 mb-2">
                  {feature.title}
                </h3>
                <p className="text-slate-600 leading-relaxed">
                  {feature.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
