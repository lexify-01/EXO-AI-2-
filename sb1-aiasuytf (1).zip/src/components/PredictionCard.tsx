import { Brain, TrendingUp } from 'lucide-react';
import type { MLPredictionResult } from '../types';

interface PredictionCardProps {
  result: MLPredictionResult;
}

export default function PredictionCard({ result }: PredictionCardProps) {
  const maxConfidence = Math.max(
    result.confidence.confirmed,
    result.confidence.candidate,
    result.confidence.false_positive
  );

  return (
    <div className="bg-gradient-to-br from-blue-50 to-slate-50 rounded-lg p-6 border border-blue-200">
      <div className="flex items-center gap-3 mb-4">
        <div className="p-2 bg-blue-100 rounded-lg">
          <Brain className="w-6 h-6 text-blue-600" />
        </div>
        <div>
          <h3 className="font-semibold text-slate-800">ML Prediction</h3>
          <p className="text-sm text-slate-600">LightGBM Classifier</p>
        </div>
      </div>

      <div className="mb-6">
        <div className="text-2xl font-bold text-slate-800 mb-2">
          {result.prediction}
        </div>
        <div className="space-y-2">
          <div>
            <div className="flex justify-between text-sm mb-1">
              <span className="text-slate-600">Confirmed</span>
              <span className="font-medium text-slate-800">
                {(result.confidence.confirmed * 100).toFixed(1)}%
              </span>
            </div>
            <div className="h-2 bg-slate-200 rounded-full overflow-hidden">
              <div
                className="h-full bg-blue-600 rounded-full"
                style={{ width: `${result.confidence.confirmed * 100}%` }}
              />
            </div>
          </div>

          <div>
            <div className="flex justify-between text-sm mb-1">
              <span className="text-slate-600">Candidate</span>
              <span className="font-medium text-slate-800">
                {(result.confidence.candidate * 100).toFixed(1)}%
              </span>
            </div>
            <div className="h-2 bg-slate-200 rounded-full overflow-hidden">
              <div
                className="h-full bg-yellow-500 rounded-full"
                style={{ width: `${result.confidence.candidate * 100}%` }}
              />
            </div>
          </div>

          <div>
            <div className="flex justify-between text-sm mb-1">
              <span className="text-slate-600">False Positive</span>
              <span className="font-medium text-slate-800">
                {(result.confidence.false_positive * 100).toFixed(1)}%
              </span>
            </div>
            <div className="h-2 bg-slate-200 rounded-full overflow-hidden">
              <div
                className="h-full bg-red-500 rounded-full"
                style={{ width: `${result.confidence.false_positive * 100}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      <div>
        <div className="flex items-center gap-2 mb-3">
          <TrendingUp className="w-4 h-4 text-slate-600" />
          <h4 className="font-semibold text-slate-800 text-sm">
            Feature Importance (SHAP)
          </h4>
        </div>
        <div className="space-y-2">
          {result.explanation.map((item, idx) => (
            <div key={idx} className="flex items-center gap-3">
              <div className="flex-1">
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-700">{item.feature}</span>
                  <span className="text-slate-500">
                    {item.value.toFixed(2)}
                  </span>
                </div>
                <div className="h-1.5 bg-slate-200 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-blue-500 to-blue-600 rounded-full"
                    style={{ width: `${(item.importance / result.explanation[0].importance) * 100}%` }}
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-4 pt-4 border-t border-slate-200">
        <p className="text-xs text-slate-500">
          Model trained on NASA Exoplanet Archive data. SHAP values explain
          how each feature contributes to the prediction.
        </p>
      </div>
    </div>
  );
}
