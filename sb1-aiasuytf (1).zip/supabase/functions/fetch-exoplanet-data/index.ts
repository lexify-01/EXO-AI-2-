import { createClient } from 'npm:@supabase/supabase-js@2.57.4';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

interface KOIRow {
  kepoi_name: string;
  kepler_name: string;
  koi_disposition: string;
  koi_period: number;
  koi_period_err1: number;
  koi_prad: number;
  koi_prad_err1: number;
  koi_teq: number;
  koi_insol: number;
  koi_depth: number;
  koi_duration: number;
  koi_model_snr: number;
  koi_steff: number;
  koi_srad: number;
  koi_smass: number;
  sy_dist: number;
  ra: number;
  dec: number;
}

interface TOIRow {
  toi: string;
  tid: string;
  tfopwg_disp: string;
  pl_orbper: number;
  pl_orbpererr1: number;
  pl_rade: number;
  pl_radeerr1: number;
  pl_eqt: number;
  pl_insol: number;
  pl_trandep: number;
  pl_trandur: number;
  st_teff: number;
  st_rad: number;
  st_mass: number;
  sy_dist: number;
  ra: number;
  dec: number;
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const url = new URL(req.url);
    const dataset = url.searchParams.get('dataset') || 'all';

    let keplerCount = 0;
    let tessCount = 0;

    if (dataset === 'all' || dataset === 'kepler') {
      console.log('Fetching Kepler KOI data...');
      const keplerUrl = 'https://exoplanetarchive.ipac.caltech.edu/cgi-bin/nstedAPI/nph-nstedAPI?table=cumulative&format=json';
      
      const keplerResponse = await fetch(keplerUrl);
      if (!keplerResponse.ok) {
        throw new Error(`Failed to fetch Kepler data: ${keplerResponse.statusText}`);
      }

      const keplerData = await keplerResponse.json() as KOIRow[];
      console.log(`Fetched ${keplerData.length} Kepler objects`);

      const keplerObjects = keplerData.slice(0, 1000).map(row => ({
        koi_name: row.kepoi_name,
        kepler_name: row.kepler_name || null,
        disposition: row.koi_disposition,
        period: row.koi_period || null,
        period_err: row.koi_period_err1 || null,
        radius: row.koi_prad || null,
        radius_err: row.koi_prad_err1 || null,
        equilibrium_temp: row.koi_teq || null,
        insolation_flux: row.koi_insol || null,
        transit_depth: row.koi_depth || null,
        transit_duration: row.koi_duration || null,
        snr: row.koi_model_snr || null,
        star_temp: row.koi_steff || null,
        star_radius: row.koi_srad || null,
        star_mass: row.koi_smass || null,
        distance: row.sy_dist || null,
        ra: row.ra || null,
        dec: row.dec || null,
        data_source: 'NASA Exoplanet Archive',
        last_updated: new Date().toISOString()
      }));

      const { error: keplerError } = await supabase
        .from('kepler_objects')
        .upsert(keplerObjects, { onConflict: 'koi_name' });

      if (keplerError) {
        console.error('Kepler insert error:', keplerError);
        throw keplerError;
      }

      keplerCount = keplerObjects.length;
      console.log(`Inserted ${keplerCount} Kepler objects`);
    }

    if (dataset === 'all' || dataset === 'tess') {
      console.log('Fetching TESS TOI data...');
      const tessUrl = 'https://exoplanetarchive.ipac.caltech.edu/cgi-bin/nstedAPI/nph-nstedAPI?table=TOI&format=json';
      
      const tessResponse = await fetch(tessUrl);
      if (!tessResponse.ok) {
        throw new Error(`Failed to fetch TESS data: ${tessResponse.statusText}`);
      }

      const tessData = await tessResponse.json() as TOIRow[];
      console.log(`Fetched ${tessData.length} TESS objects`);

      const tessObjects = tessData.slice(0, 1000).map(row => ({
        toi_name: `TOI-${row.toi}`,
        tic_id: row.tid || null,
        tfopwg_disposition: row.tfopwg_disp || 'UNKNOWN',
        period: row.pl_orbper || null,
        period_err: row.pl_orbpererr1 || null,
        radius: row.pl_rade || null,
        radius_err: row.pl_radeerr1 || null,
        equilibrium_temp: row.pl_eqt || null,
        insolation_flux: row.pl_insol || null,
        transit_depth: row.pl_trandep || null,
        transit_duration: row.pl_trandur || null,
        snr: null,
        star_temp: row.st_teff || null,
        star_radius: row.st_rad || null,
        star_mass: row.st_mass || null,
        distance: row.sy_dist || null,
        ra: row.ra || null,
        dec: row.dec || null,
        data_source: 'NASA Exoplanet Archive',
        last_updated: new Date().toISOString()
      }));

      const { error: tessError } = await supabase
        .from('tess_objects')
        .upsert(tessObjects, { onConflict: 'toi_name' });

      if (tessError) {
        console.error('TESS insert error:', tessError);
        throw tessError;
      }

      tessCount = tessObjects.length;
      console.log(`Inserted ${tessCount} TESS objects`);
    }

    return new Response(
      JSON.stringify({
        success: true,
        message: 'Data successfully imported',
        kepler_count: keplerCount,
        tess_count: tessCount
      }),
      {
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  } catch (error) {
    console.error('Error:', error);
    return new Response(
      JSON.stringify({
        success: false,
        error: error.message
      }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  }
});