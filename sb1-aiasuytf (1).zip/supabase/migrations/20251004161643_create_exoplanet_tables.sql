/*
  # Create ExoGPT Database Schema

  ## Overview
  Creates tables for NASA exoplanet data from three missions: Kepler (KOI), TESS (TOI), and K2.
  Each table stores planetary candidates with physical parameters, orbital characteristics, and classification status.

  ## New Tables

  ### 1. `kepler_objects` (KOI - Kepler Objects of Interest)
    - `id` (uuid, primary key) - Unique identifier
    - `koi_name` (text) - KOI designation (e.g., "K00001.01")
    - `kepler_name` (text, nullable) - Confirmed planet name (e.g., "Kepler-1 b")
    - `disposition` (text) - CONFIRMED / CANDIDATE / FALSE POSITIVE
    - `period` (numeric, nullable) - Orbital period in days
    - `period_err` (numeric, nullable) - Period uncertainty
    - `radius` (numeric, nullable) - Planet radius in Earth radii
    - `radius_err` (numeric, nullable) - Radius uncertainty
    - `equilibrium_temp` (numeric, nullable) - Equilibrium temperature in Kelvin
    - `insolation_flux` (numeric, nullable) - Stellar flux relative to Earth
    - `transit_depth` (numeric, nullable) - Transit depth in ppm
    - `transit_duration` (numeric, nullable) - Transit duration in hours
    - `snr` (numeric, nullable) - Signal-to-noise ratio
    - `star_temp` (numeric, nullable) - Host star effective temperature (K)
    - `star_radius` (numeric, nullable) - Host star radius in solar radii
    - `star_mass` (numeric, nullable) - Host star mass in solar masses
    - `distance` (numeric, nullable) - Distance in parsecs
    - `ra` (numeric, nullable) - Right ascension
    - `dec` (numeric, nullable) - Declination
    - `data_source` (text) - Source reference
    - `last_updated` (timestamptz) - Last update timestamp
    - `created_at` (timestamptz) - Record creation time

  ### 2. `tess_objects` (TOI - TESS Objects of Interest)
    - Similar structure to kepler_objects with TESS-specific fields
    - `toi_name` (text) - TOI designation
    - `tic_id` (text) - TESS Input Catalog ID
    - `tfopwg_disposition` (text) - CONFIRMED / PC / FP / APC / KP

  ### 3. `k2_objects` (K2 Planets and Candidates)
    - Similar structure to kepler_objects with K2-specific fields
    - `epic_id` (text) - K2 EPIC identifier
    - `archive_disposition` (text) - Classification status

  ### 4. `chat_sessions`
    - `id` (uuid, primary key) - Session identifier
    - `user_id` (uuid, nullable) - Optional user authentication
    - `created_at` (timestamptz) - Session start time
    - `last_activity` (timestamptz) - Last message time

  ### 5. `chat_messages`
    - `id` (uuid, primary key) - Message identifier
    - `session_id` (uuid, foreign key) - References chat_sessions
    - `role` (text) - 'user' or 'assistant'
    - `content` (text) - Message text
    - `metadata` (jsonb, nullable) - Query details, tool used, citations
    - `created_at` (timestamptz) - Message timestamp

  ### 6. `ml_predictions`
    - `id` (uuid, primary key) - Prediction identifier
    - `session_id` (uuid, nullable) - Optional session link
    - `input_features` (jsonb) - Input parameters
    - `prediction` (text) - CONFIRMED / CANDIDATE / FALSE POSITIVE
    - `confidence_scores` (jsonb) - Probability for each class
    - `shap_values` (jsonb) - Feature importance explanations
    - `created_at` (timestamptz) - Prediction timestamp

  ## Security
  - All tables have RLS enabled
  - Public read access for exoplanet data (research/educational use)
  - Authenticated users can create chat sessions and predictions
  - Users can only access their own sessions and predictions

  ## Indexes
  - Disposition columns for filtering
  - Period, radius, and temperature ranges for common queries
  - Distance for proximity searches
  - Session and message lookups
*/

-- Kepler Objects of Interest (KOI)
CREATE TABLE IF NOT EXISTS kepler_objects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  koi_name text UNIQUE NOT NULL,
  kepler_name text,
  disposition text NOT NULL,
  period numeric,
  period_err numeric,
  radius numeric,
  radius_err numeric,
  equilibrium_temp numeric,
  insolation_flux numeric,
  transit_depth numeric,
  transit_duration numeric,
  snr numeric,
  star_temp numeric,
  star_radius numeric,
  star_mass numeric,
  distance numeric,
  ra numeric,
  dec numeric,
  data_source text DEFAULT 'NASA Exoplanet Archive',
  last_updated timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

-- TESS Objects of Interest (TOI)
CREATE TABLE IF NOT EXISTS tess_objects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  toi_name text UNIQUE NOT NULL,
  tic_id text,
  tfopwg_disposition text NOT NULL,
  period numeric,
  period_err numeric,
  radius numeric,
  radius_err numeric,
  equilibrium_temp numeric,
  insolation_flux numeric,
  transit_depth numeric,
  transit_duration numeric,
  snr numeric,
  star_temp numeric,
  star_radius numeric,
  star_mass numeric,
  distance numeric,
  ra numeric,
  dec numeric,
  data_source text DEFAULT 'NASA Exoplanet Archive',
  last_updated timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

-- K2 Planets and Candidates
CREATE TABLE IF NOT EXISTS k2_objects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  epic_id text UNIQUE NOT NULL,
  planet_name text,
  archive_disposition text NOT NULL,
  period numeric,
  period_err numeric,
  radius numeric,
  radius_err numeric,
  equilibrium_temp numeric,
  insolation_flux numeric,
  transit_depth numeric,
  transit_duration numeric,
  snr numeric,
  star_temp numeric,
  star_radius numeric,
  star_mass numeric,
  distance numeric,
  ra numeric,
  dec numeric,
  data_source text DEFAULT 'NASA Exoplanet Archive',
  last_updated timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

-- Chat Sessions
CREATE TABLE IF NOT EXISTS chat_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid,
  created_at timestamptz DEFAULT now(),
  last_activity timestamptz DEFAULT now()
);

-- Chat Messages
CREATE TABLE IF NOT EXISTS chat_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid NOT NULL REFERENCES chat_sessions(id) ON DELETE CASCADE,
  role text NOT NULL CHECK (role IN ('user', 'assistant')),
  content text NOT NULL,
  metadata jsonb,
  created_at timestamptz DEFAULT now()
);

-- ML Predictions
CREATE TABLE IF NOT EXISTS ml_predictions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid REFERENCES chat_sessions(id),
  input_features jsonb NOT NULL,
  prediction text NOT NULL,
  confidence_scores jsonb NOT NULL,
  shap_values jsonb,
  created_at timestamptz DEFAULT now()
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_koi_disposition ON kepler_objects(disposition);
CREATE INDEX IF NOT EXISTS idx_koi_period ON kepler_objects(period) WHERE period IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_koi_radius ON kepler_objects(radius) WHERE radius IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_koi_distance ON kepler_objects(distance) WHERE distance IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_koi_star_temp ON kepler_objects(star_temp) WHERE star_temp IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_toi_disposition ON tess_objects(tfopwg_disposition);
CREATE INDEX IF NOT EXISTS idx_toi_period ON tess_objects(period) WHERE period IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_toi_radius ON tess_objects(radius) WHERE radius IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_toi_distance ON tess_objects(distance) WHERE distance IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_toi_star_temp ON tess_objects(star_temp) WHERE star_temp IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_k2_disposition ON k2_objects(archive_disposition);
CREATE INDEX IF NOT EXISTS idx_k2_period ON k2_objects(period) WHERE period IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_k2_radius ON k2_objects(radius) WHERE radius IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_k2_distance ON k2_objects(distance) WHERE distance IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_chat_messages_session ON chat_messages(session_id, created_at);
CREATE INDEX IF NOT EXISTS idx_ml_predictions_session ON ml_predictions(session_id);

-- Enable Row Level Security
ALTER TABLE kepler_objects ENABLE ROW LEVEL SECURITY;
ALTER TABLE tess_objects ENABLE ROW LEVEL SECURITY;
ALTER TABLE k2_objects ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE ml_predictions ENABLE ROW LEVEL SECURITY;

-- RLS Policies: Exoplanet data is publicly readable (research/educational)
CREATE POLICY "Exoplanet data is publicly readable"
  ON kepler_objects FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Exoplanet data is publicly readable"
  ON tess_objects FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Exoplanet data is publicly readable"
  ON k2_objects FOR SELECT
  TO public
  USING (true);

-- RLS Policies: Chat sessions
CREATE POLICY "Anyone can create chat sessions"
  ON chat_sessions FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Users can view their own sessions"
  ON chat_sessions FOR SELECT
  TO public
  USING (user_id IS NULL OR user_id = auth.uid());

CREATE POLICY "Users can update their own sessions"
  ON chat_sessions FOR UPDATE
  TO public
  USING (user_id IS NULL OR user_id = auth.uid())
  WITH CHECK (user_id IS NULL OR user_id = auth.uid());

-- RLS Policies: Chat messages
CREATE POLICY "Anyone can create messages"
  ON chat_messages FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Anyone can view messages in accessible sessions"
  ON chat_messages FOR SELECT
  TO public
  USING (
    EXISTS (
      SELECT 1 FROM chat_sessions
      WHERE chat_sessions.id = chat_messages.session_id
      AND (chat_sessions.user_id IS NULL OR chat_sessions.user_id = auth.uid())
    )
  );

-- RLS Policies: ML predictions
CREATE POLICY "Anyone can create predictions"
  ON ml_predictions FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Anyone can view predictions"
  ON ml_predictions FOR SELECT
  TO public
  USING (
    session_id IS NULL OR
    EXISTS (
      SELECT 1 FROM chat_sessions
      WHERE chat_sessions.id = ml_predictions.session_id
      AND (chat_sessions.user_id IS NULL OR chat_sessions.user_id = auth.uid())
    )
  );